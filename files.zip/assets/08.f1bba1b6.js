const s="/assets/08.41dbf9d2.jpg";export{s as c};
