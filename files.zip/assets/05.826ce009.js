const s="/assets/01.4b5850a8.jpg",a="/assets/05.faf100be.jpg";export{a,s};
