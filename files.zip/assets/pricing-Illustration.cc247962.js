const s="/assets/pricing-Illustration.548b1cd1.svg";export{s as i};
