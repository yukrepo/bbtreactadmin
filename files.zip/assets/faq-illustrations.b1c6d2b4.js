const s="/assets/faq-illustrations.0a8a9367.svg";export{s as i};
