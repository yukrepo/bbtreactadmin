import{a as r}from"./editor.a3bcf4e5.js";var t=r();export{t as D};
