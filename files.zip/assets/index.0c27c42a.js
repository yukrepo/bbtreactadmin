import{I as t,k as e,bP as h,ag as g,bQ as p,r as H,bN as k}from"./index.4b8b4a4a.js";import{R as j,C as D}from"./Col.bfc217ec.js";import{C as f}from"./CardBody.33315e76.js";import{C as T}from"./CardText.d4bc0ae9.js";import{A as r}from"./index.76d500d2.js";import{B as l,U as d,e as s,f as n,h as i,t as o}from"./App.bd85fbba.js";import{T as v}from"./Table.406defab.js";import{M as c}from"./more-vertical.5c7e6860.js";import{T as m}from"./trash.25846df0.js";import{C as b}from"./index.59836514.js";import{B as G}from"./index.64b915db.js";import"./UncontrolledTooltip.452ecfbb.js";import"./TooltipPopoverWrapper.a0fe7814.js";import"./Fade.f5aeb593.js";import"./Card.72d7b0d9.js";import"./CardHeader.674dc5eb.js";import"./CardTitle.5bb3554b.js";import"./code.ad32cd2b.js";import"./UncontrolledButtonDropdown.37d5fbe4.js";const w="/assets/react.3ed3d75a.svg",z="/assets/vuejs.a95b62d6.svg",N="/assets/angular.1b18ceb5.svg",u="/assets/bootstrap.6f7e65e6.svg",I=[{title:"Levi",img:h,imgHeight:26,imgWidth:26},{title:"Nina",img:g,imgHeight:26,imgWidth:26},{title:"Brynn",img:p,imgHeight:26,imgWidth:26}],M=[{title:"Liberty",img:h,imgHeight:26,imgWidth:26},{title:"Fallon",img:g,imgHeight:26,imgWidth:26},{title:"Minerva",img:p,imgHeight:26,imgWidth:26}],B=[{title:"Palmer",img:h,imgHeight:26,imgWidth:26},{title:"Tana",img:g,imgHeight:26,imgWidth:26},{title:"Evangeline",img:p,imgHeight:26,imgWidth:26}],P=[{title:"Winter",img:h,imgHeight:26,imgWidth:26},{title:"Carl",img:g,imgHeight:26,imgWidth:26},{title:"Andrew",img:p,imgHeight:26,imgWidth:26}],E=()=>t(v,{dark:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:I})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:M})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:B})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:P})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),A=[{title:"Lilian",img:h,imgHeight:26,imgWidth:26},{title:"Alberto",img:g,imgHeight:26,imgWidth:26},{title:"Bruce",img:p,imgHeight:26,imgWidth:26}],y=[{title:"Diana",img:h,imgHeight:26,imgWidth:26},{title:"Rey",img:g,imgHeight:26,imgWidth:26},{title:"James",img:p,imgHeight:26,imgWidth:26}],U=[{title:"Lee",img:h,imgHeight:26,imgWidth:26},{title:"Mario",img:g,imgHeight:26,imgWidth:26},{title:"Oswald",img:p,imgHeight:26,imgWidth:26}],x=[{title:"Christie",img:h,imgHeight:26,imgWidth:26},{title:"Barnes",img:g,imgHeight:26,imgWidth:26},{title:"Arthur",img:p,imgHeight:26,imgWidth:26}],C=()=>t(v,{responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:A})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:y})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:U})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:x})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),V=[{title:"Griffith",img:h,imgHeight:26,imgWidth:26},{title:"Hu",img:g,imgHeight:26,imgWidth:26},{title:"Felicia",img:p,imgHeight:26,imgWidth:26}],S=[{title:"Quinlan",img:h,imgHeight:26,imgWidth:26},{title:"Patrick",img:g,imgHeight:26,imgWidth:26},{title:"Castor",img:p,imgHeight:26,imgWidth:26}],J=[{title:"Mohammad",img:h,imgHeight:26,imgWidth:26},{title:"Isabella",img:g,imgHeight:26,imgWidth:26},{title:"Michael",img:p,imgHeight:26,imgWidth:26}],R=[{title:"Lavinia",img:h,imgHeight:26,imgWidth:26},{title:"Nelle",img:g,imgHeight:26,imgWidth:26},{title:"Virginia",img:p,imgHeight:26,imgWidth:26}],F=()=>t(v,{hover:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:V})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:S})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:J})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:R})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),$=[{title:"Melissa",img:h,imgHeight:22,imgWidth:22},{title:"Jana",img:g,imgHeight:22,imgWidth:22},{title:"Halla",img:p,imgHeight:22,imgWidth:22}],L=[{title:"Wing",img:h,imgHeight:22,imgWidth:22},{title:"Octavia",img:g,imgHeight:22,imgWidth:22},{title:"Benedict",img:p,imgHeight:22,imgWidth:22}],O=[{title:"Jade",img:h,imgHeight:22,imgWidth:22},{title:"Alisa",img:g,imgHeight:22,imgWidth:22},{title:"Alisa",img:p,imgHeight:22,imgWidth:22}],K=[{title:"Alexa",img:h,imgHeight:22,imgWidth:22},{title:"Lee",img:g,imgHeight:22,imgWidth:22},{title:"Shellie",img:p,imgHeight:22,imgWidth:22}],Q=()=>t(v,{size:"sm",responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"18",width:"18"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:$})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"18",width:"18"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:L})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"18",width:"18"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:O})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"18",width:"18"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:K})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),Y=[{title:"Gretchen",img:h,imgHeight:26,imgWidth:26},{title:"Hunter",img:g,imgHeight:26,imgWidth:26},{title:"Allistair",img:p,imgHeight:26,imgWidth:26}],Z=[{title:"Macy",img:h,imgHeight:26,imgWidth:26},{title:"Eve",img:g,imgHeight:26,imgWidth:26},{title:"Damian",img:p,imgHeight:26,imgWidth:26}],q=[{title:"Jade",img:h,imgHeight:26,imgWidth:26},{title:"Destiny",img:g,imgHeight:26,imgWidth:26},{title:"Cade",img:p,imgHeight:26,imgWidth:26}],X=[{title:"Bruno",img:h,imgHeight:26,imgWidth:26},{title:"Griffin",img:g,imgHeight:26,imgWidth:26},{title:"Anthony",img:p,imgHeight:26,imgWidth:26}],_=()=>t(v,{striped:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:Y})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:Z})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:q})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:X})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),ee=[{title:"Leslie",img:h,imgHeight:26,imgWidth:26},{title:"Quinn",img:g,imgHeight:26,imgWidth:26},{title:"Quinn",img:p,imgHeight:26,imgWidth:26}],te=[{title:"Felicia",img:h,imgHeight:26,imgWidth:26},{title:"Brent",img:g,imgHeight:26,imgWidth:26},{title:"Patricia",img:p,imgHeight:26,imgWidth:26}],ae=[{title:"Breanna",img:h,imgHeight:26,imgWidth:26},{title:"Peter",img:g,imgHeight:26,imgWidth:26},{title:"Cherokee",img:p,imgHeight:26,imgWidth:26}],ie=[{title:"Martina",img:h,imgHeight:26,imgWidth:26},{title:"Butcher",img:g,imgHeight:26,imgWidth:26},{title:"Noel",img:p,imgHeight:26,imgWidth:26}],re=()=>t(v,{bordered:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:ee})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:te})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:ae})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:ie})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),le=[{title:"Adara",img:h,imgHeight:26,imgWidth:26},{title:"Kalia ",img:g,imgHeight:26,imgWidth:26},{title:"Oliver",img:p,imgHeight:26,imgWidth:26}],de=[{title:"Tyler",img:h,imgHeight:26,imgWidth:26},{title:"Hanae",img:g,imgHeight:26,imgWidth:26},{title:"Brynn",img:p,imgHeight:26,imgWidth:26}],se=[{title:"Tate",img:h,imgHeight:26,imgWidth:26},{title:"Norman",img:g,imgHeight:26,imgWidth:26},{title:"Lana",img:p,imgHeight:26,imgWidth:26}],ne=[{title:"Emerald",img:h,imgHeight:26,imgWidth:26},{title:"Sebastian",img:g,imgHeight:26,imgWidth:26},{title:"Jamal",img:p,imgHeight:26,imgWidth:26}],oe=()=>t(v,{responsive:!0,children:[e("thead",{className:"table-dark",children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:le})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:de})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:se})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:ne})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),W="/assets/figma.0df0b8f9.svg",ce=[{title:"Illiana",img:h,imgHeight:26,imgWidth:26},{title:"Wyatt",img:g,imgHeight:26,imgWidth:26},{title:"Troy",img:p,imgHeight:26,imgWidth:26}],me=[{title:"Mufutau",img:h,imgHeight:26,imgWidth:26},{title:"Denton",img:g,imgHeight:26,imgWidth:26},{title:"Carol",img:p,imgHeight:26,imgWidth:26}],he=[{title:"Kyla",img:h,imgHeight:26,imgWidth:26},{title:"Hop",img:g,imgHeight:26,imgWidth:26},{title:"Yvonne",img:p,imgHeight:26,imgWidth:26}],ge=[{title:"Lunea",img:h,imgHeight:26,imgWidth:26},{title:"Francis",img:g,imgHeight:26,imgWidth:26},{title:"Kameko",img:p,imgHeight:26,imgWidth:26}],pe=[{title:"Blair",img:h,imgHeight:26,imgWidth:26},{title:"Aspen",img:g,imgHeight:26,imgWidth:26},{title:"Tyler",img:p,imgHeight:26,imgWidth:26}],ue=[{title:"Florence",img:h,imgHeight:26,imgWidth:26},{title:"Kieran",img:g,imgHeight:26,imgWidth:26},{title:"Anthony",img:p,imgHeight:26,imgWidth:26}],De=[{title:"Lysandra",img:h,imgHeight:26,imgWidth:26},{title:"Russell",img:g,imgHeight:26,imgWidth:26},{title:"Curran",img:p,imgHeight:26,imgWidth:26}],we=[{title:"Britanney",img:h,imgHeight:26,imgWidth:26},{title:"Avye",img:g,imgHeight:26,imgWidth:26},{title:"Castor",img:p,imgHeight:26,imgWidth:26}],Ne=[{title:"Charissa",img:h,imgHeight:26,imgWidth:26},{title:"Elijah",img:g,imgHeight:26,imgWidth:26},{title:"Giacomo",img:p,imgHeight:26,imgWidth:26}],ve=[{title:"Chaim",img:h,imgHeight:26,imgWidth:26},{title:"Virginia",img:g,imgHeight:26,imgWidth:26},{title:"Kristen",img:p,imgHeight:26,imgWidth:26}],fe=()=>t(v,{responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{className:"table-default",children:[t("td",{children:[e("img",{className:"me-75",src:W,alt:"figma",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Figma Project"})]}),e("td",{children:"Ronnie Shane"}),t("td",{children:[e(r,{data:ce})," "]}),e("td",{children:e(l,{pill:!0,color:"light-primary",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-active",children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:me})}),e("td",{children:e(l,{pill:!0,color:"light-success",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-primary",children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charls"}),e("td",{children:e(r,{data:he})}),e("td",{children:e(l,{pill:!0,color:"light-primary",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-secondary",children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:ge})}),e("td",{children:e(l,{pill:!0,color:"light-secondary",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-success",children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:pe})}),e("td",{children:e(l,{pill:!0,color:"light-success",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-danger",children:[t("td",{children:[e("img",{className:"me-75",src:W,alt:"figma",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Figma Project"})]}),e("td",{children:"Janne Ale"}),e("td",{children:e(r,{data:ue})}),e("td",{children:e(l,{pill:!0,color:"light-danger",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-warning",children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Custom"})]}),e("td",{children:"Ted Richer"}),e("td",{children:e(r,{data:De})}),e("td",{children:e(l,{pill:!0,color:"light-warning",children:"Schedule"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-info",children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Latest Bootstrap"})]}),e("td",{children:"Perry Parker"}),e("td",{children:e(r,{data:we})}),e("td",{children:e(l,{pill:!0,color:"light-info",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-light",children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular UI"})]}),e("td",{children:"Ana Bell"}),e("td",{children:e(r,{data:Ne})}),e("td",{children:e(l,{pill:!0,color:"light-primary",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{className:"table-dark",children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap UI"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:ve})}),e("td",{children:e(l,{pill:!0,color:"light-dark",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),be=()=>t(v,{responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{scope:"col",className:"text-nowrap",children:"#"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 1"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 2"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 3"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 4"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 5"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 6"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 7"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 8"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 9"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 10"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 11"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 12"}),e("th",{scope:"col",className:"text-nowrap",children:"Heading 13"})]})}),t("tbody",{children:[t("tr",{children:[e("td",{className:"text-nowrap",children:"1"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"}),e("td",{className:"text-nowrap",children:"Table cell"})]}),t("tr",{children:[e("td",{children:"2"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"})]}),t("tr",{children:[e("td",{children:"3"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"})]}),t("tr",{children:[e("td",{children:"4"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"}),e("td",{children:"Table cell"})]})]})]}),ze=[{title:"Sarah",img:h,imgHeight:26,imgWidth:26},{title:"Ainsley",img:g,imgHeight:26,imgWidth:26},{title:"Charissa",img:p,imgHeight:26,imgWidth:26}],Te=[{title:"Vanna",img:h,imgHeight:26,imgWidth:26},{title:"Inga",img:g,imgHeight:26,imgWidth:26},{title:"Patricia",img:p,imgHeight:26,imgWidth:26}],He=[{title:"Justina",img:h,imgHeight:26,imgWidth:26},{title:"Lamar",img:g,imgHeight:26,imgWidth:26},{title:"Briar",img:p,imgHeight:26,imgWidth:26}],Ce=[{title:"Jenette",img:h,imgHeight:26,imgWidth:26},{title:"Francis",img:g,imgHeight:26,imgWidth:26},{title:"Isaac",img:p,imgHeight:26,imgWidth:26}],We=()=>t(v,{borderless:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:ze})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:Te})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:He})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:Ce})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),ke=[{title:"Aristotle",img:h,imgHeight:26,imgWidth:26},{title:"Nolan ",img:g,imgHeight:26,imgWidth:26},{title:"Baxter",img:p,imgHeight:26,imgWidth:26}],je=[{title:"Zane",img:h,imgHeight:26,imgWidth:26},{title:"Tatum",img:g,imgHeight:26,imgWidth:26},{title:"Rae",img:p,imgHeight:26,imgWidth:26}],Ge=[{title:"Rhiannon",img:h,imgHeight:26,imgWidth:26},{title:"William",img:g,imgHeight:26,imgWidth:26},{title:"Vaughan",img:p,imgHeight:26,imgWidth:26}],Ie=[{title:"Unity",img:h,imgHeight:26,imgWidth:26},{title:"Emerson",img:g,imgHeight:26,imgWidth:26},{title:"Ima",img:p,imgHeight:26,imgWidth:26}],Me=()=>t(v,{responsive:!0,children:[e("thead",{className:"table-light",children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:ke})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:je})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:Ge})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:Ie})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),Be=[{title:"Galvin",img:h,imgHeight:26,imgWidth:26},{title:"Malcolm",img:g,imgHeight:26,imgWidth:26},{title:"Leo",img:p,imgHeight:26,imgWidth:26}],Pe=[{title:"Nola",img:h,imgHeight:26,imgWidth:26},{title:"Brett",img:g,imgHeight:26,imgWidth:26},{title:"Harper",img:p,imgHeight:26,imgWidth:26}],Ee=[{title:"Jamalia",img:h,imgHeight:26,imgWidth:26},{title:"Arden",img:g,imgHeight:26,imgWidth:26},{title:"Laith",img:p,imgHeight:26,imgWidth:26}],Ae=[{title:"Kirby",img:h,imgHeight:26,imgWidth:26},{title:"Forrest",img:g,imgHeight:26,imgWidth:26},{title:"Jordan",img:p,imgHeight:26,imgWidth:26}],ye=()=>t(v,{striped:!0,dark:!0,responsive:!0,children:[e("thead",{children:t("tr",{children:[e("th",{children:"Project"}),e("th",{children:"Client"}),e("th",{children:"Users"}),e("th",{children:"Status"}),e("th",{children:"Actions"})]})}),t("tbody",{children:[t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:N,alt:"angular",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Angular Project"})]}),e("td",{children:"Peter Charles"}),e("td",{children:e(r,{data:Be})}),e("td",{children:e(l,{pill:!0,color:"light-primary",className:"me-1",children:"Active"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:w,alt:"react",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"React Project"})]}),e("td",{children:"Ronald Frest"}),e("td",{children:e(r,{data:Pe})}),e("td",{children:e(l,{pill:!0,color:"light-success",className:"me-1",children:"Completed"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:z,alt:"vuejs",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Vuejs Project"})]}),e("td",{children:"Jack Obes"}),e("td",{children:e(r,{data:Ee})}),e("td",{children:e(l,{pill:!0,color:"light-info",className:"me-1",children:"Scheduled"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]}),t("tr",{children:[t("td",{children:[e("img",{className:"me-75",src:u,alt:"bootstrap",height:"20",width:"20"}),e("span",{className:"align-middle fw-bold",children:"Bootstrap Project"})]}),e("td",{children:"Jerry Milton"}),e("td",{children:e(r,{data:Ae})}),e("td",{children:e(l,{pill:!0,color:"light-warning",className:"me-1",children:"Pending"})}),e("td",{children:t(d,{children:[e(s,{className:"icon-btn hide-arrow text-white",color:"transparent",size:"sm",caret:!0,children:e(c,{size:15})}),t(n,{children:[t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(o,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Edit"})]}),t(i,{href:"/",onClick:a=>a.preventDefault(),children:[e(m,{className:"me-50",size:15})," ",e("span",{className:"align-middle",children:"Delete"})]})]})]})})]})]})]}),Ue=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Lilian',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Alberto',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Bruce',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Diana',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Rey',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'James',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Lee',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Mario',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Oswald',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Christie',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Barnes',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Arthur',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableBasic = () => {
  return (
    <Table responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableBasic
`})}),xe=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Levi',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Nina',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Brynn',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Liberty',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Fallon',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Minerva',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Palmer',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Tana',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Evangeline',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Winter',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Carl',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Andrew',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableDark = () => {
  return (
    <Table dark responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableDark
`})}),Ve=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Adara',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Kalia ',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Oliver',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Tyler',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Hanae',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Brynn',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Tate',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Norman',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Lana',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Emerald',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Sebastian',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Jamal',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]
// Change class to table-light for light variant
const TableTheadDark = () => {
  return (
    <Table responsive>
      <thead className='table-dark'>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableTheadDark`})}),Se=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Gretchen',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Hunter',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Allistair',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Macy',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Eve',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Damian',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Jade',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Destiny',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Cade',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Bruno',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Griffin',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Anthony',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableStriped = () => {
  return (
    <Table striped responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableStriped
`})}),Je=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Galvin',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Malcolm',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Leo',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Nola',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Brett',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Harper',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Jamalia',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Arden',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Laith',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Kirby',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Forrest',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Jordan',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]
const TableStripedDark = () => {
  return (
    <Table striped dark responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow text-white' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableStripedDark
`})}),Re=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Sarah',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Ainsley',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Charissa',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Vanna',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Inga',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Patricia',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Justina',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Lamar',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Briar',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Jenette',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Francis',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Isaac',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableBorderless = () => {
  return (
    <Table borderless responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableBorderless
`})}),Fe=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Leslie',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Quinn',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Quinn',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Felicia',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Brent',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Patricia',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Breanna',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Peter',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Cherokee',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Martina',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Butcher',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Noel',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableBordered = () => {
  return (
    <Table bordered responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableBordered
`})}),$e=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Griffith',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Hu',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Felicia',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Quinlan',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Patrick',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Castor',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Mohammad',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Isabella',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Michael',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Lavinia',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Nelle',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Virginia',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableHover = () => {
  return (
    <Table hover responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableHover
`})}),Le=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Melissa',
    img: avatar1,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Jana',
    img: avatar2,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Halla',
    img: avatar3,
    imgHeight: 22,
    imgWidth: 22
  }
]

const avatarGroupData2 = [
  {
    title: 'Wing',
    img: avatar1,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Octavia',
    img: avatar2,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Benedict',
    img: avatar3,
    imgHeight: 22,
    imgWidth: 22
  }
]

const avatarGroupData3 = [
  {
    title: 'Jade',
    img: avatar1,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Alisa',
    img: avatar2,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Alisa',
    img: avatar3,
    imgHeight: 22,
    imgWidth: 22
  }
]

const avatarGroupData4 = [
  {
    title: 'Alexa',
    img: avatar1,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Lee',
    img: avatar2,
    imgHeight: 22,
    imgWidth: 22
  },
  {
    title: 'Shellie',
    img: avatar3,
    imgHeight: 22,
    imgWidth: 22
  }
]

const TableSmall = () => {
  return (
    <Table size='sm' responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <img className='me-75' src={angular} alt='angular' height='18' width='18' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charles</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />
          </td>
          <td>
            <Badge pill color='light-primary' className='me-1'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={react} alt='react' height='18' width='18' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success' className='me-1'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='18' width='18' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-info' className='me-1'>
              Scheduled
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='18' width='18' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-warning' className='me-1'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableSmall
`})}),Oe=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import AvatarGroup from '@components/avatar-group'
import react from '@src/assets/images/icons/react.svg'
import figma from '@src/assets/images/icons/figma.svg'
import vuejs from '@src/assets/images/icons/vuejs.svg'
import angular from '@src/assets/images/icons/angular.svg'
import bootstrap from '@src/assets/images/icons/bootstrap.svg'
import avatar1 from '@src/assets/images/portrait/small/avatar-s-5.jpg'
import avatar2 from '@src/assets/images/portrait/small/avatar-s-6.jpg'
import avatar3 from '@src/assets/images/portrait/small/avatar-s-7.jpg'
import { MoreVertical, Edit, Trash } from 'react-feather'
import { Table, Badge, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap'

const avatarGroupData1 = [
  {
    title: 'Illiana',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Wyatt',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Troy',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData2 = [
  {
    title: 'Mufutau',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Denton',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Carol',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData3 = [
  {
    title: 'Kyla',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Hop',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Yvonne',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData4 = [
  {
    title: 'Lunea',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Francis',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Kameko',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData5 = [
  {
    title: 'Blair',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Aspen',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Tyler',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData6 = [
  {
    title: 'Florence',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Kieran',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Anthony',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData7 = [
  {
    title: 'Lysandra',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Russell',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Curran',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData8 = [
  {
    title: 'Britanney',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Avye',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Castor',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData9 = [
  {
    title: 'Charissa',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Elijah',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Giacomo',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const avatarGroupData10 = [
  {
    title: 'Chaim',
    img: avatar1,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Virginia',
    img: avatar2,
    imgHeight: 26,
    imgWidth: 26
  },
  {
    title: 'Kristen',
    img: avatar3,
    imgHeight: 26,
    imgWidth: 26
  }
]

const TableContextual = () => {
  return (
    <Table responsive>
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Users</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr className='table-default'>
          <td>
            <img className='me-75' src={figma} alt='figma' height='20' width='20' />
            <span className='align-middle fw-bold'>Figma Project</span>
          </td>
          <td>Ronnie Shane</td>
          <td>
            <AvatarGroup data={avatarGroupData1} />{' '}
          </td>
          <td>
            <Badge pill color='light-primary'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-active'>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Project</span>
          </td>
          <td>Ronald Frest</td>
          <td>
            <AvatarGroup data={avatarGroupData2} />
          </td>
          <td>
            <Badge pill color='light-success'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-primary'>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular Project</span>
          </td>
          <td>Peter Charls</td>
          <td>
            <AvatarGroup data={avatarGroupData3} />
          </td>
          <td>
            <Badge pill color='light-primary'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-secondary'>
          <td>
            <img className='me-75' src={vuejs} alt='vuejs' height='20' width='20' />
            <span className='align-middle fw-bold'>Vuejs Project</span>
          </td>
          <td>Jack Obes</td>
          <td>
            <AvatarGroup data={avatarGroupData4} />
          </td>
          <td>
            <Badge pill color='light-secondary'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-success'>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap Project</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData5} />
          </td>
          <td>
            <Badge pill color='light-success'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-danger'>
          <td>
            <img className='me-75' src={figma} alt='figma' height='20' width='20' />
            <span className='align-middle fw-bold'>Figma Project</span>
          </td>
          <td>Janne Ale</td>
          <td>
            <AvatarGroup data={avatarGroupData6} />
          </td>
          <td>
            <Badge pill color='light-danger'>
              Active
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-warning'>
          <td>
            <img className='me-75' src={react} alt='react' height='20' width='20' />
            <span className='align-middle fw-bold'>React Custom</span>
          </td>
          <td>Ted Richer</td>
          <td>
            <AvatarGroup data={avatarGroupData7} />
          </td>
          <td>
            <Badge pill color='light-warning'>
              Schedule
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-info'>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Latest Bootstrap</span>
          </td>
          <td>Perry Parker</td>
          <td>
            <AvatarGroup data={avatarGroupData8} />
          </td>
          <td>
            <Badge pill color='light-info'>
              Pending
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-light'>
          <td>
            <img className='me-75' src={angular} alt='angular' height='20' width='20' />
            <span className='align-middle fw-bold'>Angular UI</span>
          </td>
          <td>Ana Bell</td>
          <td>
            <AvatarGroup data={avatarGroupData9} />
          </td>
          <td>
            <Badge pill color='light-primary'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
        <tr className='table-dark'>
          <td>
            <img className='me-75' src={bootstrap} alt='bootstrap' height='20' width='20' />
            <span className='align-middle fw-bold'>Bootstrap UI</span>
          </td>
          <td>Jerry Milton</td>
          <td>
            <AvatarGroup data={avatarGroupData10} />
          </td>
          <td>
            <Badge pill color='light-dark'>
              Completed
            </Badge>
          </td>
          <td>
            <UncontrolledDropdown>
              <DropdownToggle className='icon-btn hide-arrow' color='transparent' size='sm' caret>
                <MoreVertical size={15} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Edit className='me-50' size={15} /> <span className='align-middle'>Edit</span>
                </DropdownItem>
                <DropdownItem href='/' onClick={e => e.preventDefault()}>
                  <Trash className='me-50' size={15} /> <span className='align-middle'>Delete</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableContextual
`})}),Ke=e("pre",{className:"language-jsx",children:e("code",{className:"language-jsx",children:`
import { Table } from 'reactstrap'

const TableResponsive = () => {
  return (
    <Table responsive>
      <thead>
        <tr>
          <th scope='col' className='text-nowrap'>
            #
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 1
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 2
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 3
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 4
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 5
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 6
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 7
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 8
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 9
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 10
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 11
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 12
          </th>
          <th scope='col' className='text-nowrap'>
            Heading 13
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td className='text-nowrap'>1</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
          <td className='text-nowrap'>Table cell</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
        </tr>
        <tr>
          <td>3</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
        </tr>
        <tr>
          <td>4</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
          <td>Table cell</td>
        </tr>
      </tbody>
    </Table>
  )
}

export default TableResponsive
`})}),gt=()=>(H.exports.useEffect(()=>{k.highlightAll()}),t(H.exports.Fragment,{children:[e(G,{title:"Reactstrap Tables",data:[{title:"Forms & Tables"},{title:"Tables"}]}),t(j,{children:[e(D,{sm:"12",children:e(b,{title:"Basic",code:Ue,noBody:!0,children:e(C,{})})}),e(D,{sm:"12",children:t(b,{title:"Dark",code:xe,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"dark"})," to create a dark inverted table."]})}),e(E,{})]})}),e(D,{sm:"12",children:t(b,{title:"Table head Options",code:Ve,noBody:!0,children:[e(f,{children:t(T,{children:["Similar to tables and dark tables, use the modifier classes ",e("code",{children:".table-dark"})," to make"," ",e("code",{children:"<thead>"})," appear dark."]})}),e(oe,{}),e(f,{className:"mt-2",children:t("p",{className:"m-0",children:["Use the modifier class ",e("code",{children:".table-light"})," to make ",e("code",{children:"<thead>"})," appear light."]})}),e(Me,{})]})}),e(D,{sm:"12",children:t(b,{title:"Striped",code:Se,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"striped"})," to create a striped table."]})}),e(_,{})]})}),e(D,{sm:"12",children:t(b,{title:"Striped Dark",code:Je,noBody:!0,children:[e(f,{children:t(T,{children:["Use props ",e("code",{children:"striped"})," & ",e("code",{children:"dark"})," to create a dark striped table."]})}),e(ye,{})]})}),e(D,{sm:"12",children:t(b,{title:"Bordered",code:Fe,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"bordered"})," to create a bordered table."]})}),e(re,{})]})}),e(D,{sm:"12",children:t(b,{title:"Borderless",code:Re,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"borderless"})," to create a borderless table."]})}),e(We,{})]})}),e(D,{sm:"12",children:t(b,{title:"Hoverable",code:$e,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"hover"})," to create a hoverable table."]})}),e(F,{})]})}),e(D,{sm:"12",children:t(b,{title:"Small",code:Le,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:'size="sm"'})," to create a small table."]})}),e(Q,{})]})}),e(D,{sm:"12",children:t(b,{title:"Contextual classes",code:Oe,noBody:!0,children:[e(f,{children:t(T,{children:["Use class ",e("code",{children:"table-[colorName]"})," with ",e("code",{children:"<tr>"})," for contextual rows."]})}),e(fe,{})]})}),t(D,{className:"my-2",sm:"12",children:[e("h5",{className:"mb-1",children:"Table without card"}),e(C,{})]}),e(D,{sm:"12",children:t(b,{title:"Responsive",code:Ke,noBody:!0,children:[e(f,{children:t(T,{children:["Use prop ",e("code",{children:"responsive"})," to make your table responsive."]})}),e(be,{})]})})]})]}));export{gt as default};
