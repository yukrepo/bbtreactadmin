const s="/assets/login-v2.f073f8a2.svg",a="/assets/login-v2-dark.28044871.svg";export{s as a,a as i};
