const s="/assets/register-v2.ed09ac98.svg",t="/assets/register-v2-dark.f4c54222.svg";export{s as a,t as i};
