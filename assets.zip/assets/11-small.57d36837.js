const a="/assets/11-small.eb1188f5.png";export{a};
