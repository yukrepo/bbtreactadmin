const s="/assets/forgot-password-v2.5364645d.svg",t="/assets/forgot-password-v2-dark.d5b55466.svg";export{s as a,t as i};
