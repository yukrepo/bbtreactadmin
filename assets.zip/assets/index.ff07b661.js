import{I as t,k as n,r as f,bP as d}from"./index.3cf7fe2c.js";import{R as P,C as r}from"./Col.6ede14e5.js";import{C as l}from"./CardText.a1018b16.js";import{C as g}from"./index.c1668105.js";import{B as m}from"./index.7b231c77.js";import{P as o,a as e,b as a}from"./PaginationLink.8dad1d82.js";import{C as c}from"./chevron-left.5a5c2a04.js";import{C as h}from"./chevron-right.8aea7c11.js";import"./Card.84516876.js";import"./CardBody.34141036.js";import"./CardHeader.acdabf3c.js";import"./CardTitle.51f38a88.js";import"./App.078e8de4.js";import"./code.ac4caa14.js";import"./UncontrolledButtonDropdown.3408d595.js";const s=()=>t(o,{className:"d-flex mt-3",listClassName:"pagination-info",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),first:!0,children:n(c,{size:15})})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),last:!0,children:n(h,{size:15})})})]}),k=()=>t(o,{className:"d-flex mt-3",children:[n(e,{children:n(a,{href:"#",first:!0,onClick:i=>i.preventDefault(),children:n(c,{size:15})})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",last:!0,onClick:i=>i.preventDefault(),children:n(h,{size:15})})})]}),L=()=>t(o,{className:"d-flex mt-3",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})})]}),I=()=>t(P,{className:"align-items-center",children:[n(r,{xl:"4",lg:"12",children:t(o,{size:"lg",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})}),n(r,{xl:"4",lg:"12",children:t(o,{children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})}),n(r,{xl:"4",lg:"12",children:t(o,{size:"sm",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})})]}),p=()=>t(o,{className:"d-flex mt-3",listClassName:"pagination-danger",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),first:!0,children:n(c,{size:15})})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),last:!0,children:n(h,{size:15})})})]}),u=()=>t(o,{className:"d-flex mt-3",listClassName:"pagination-success",children:[n(e,{children:n(a,{href:"#",first:!0,onClick:i=>i.preventDefault(),children:n(c,{size:15})})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})}),n(e,{children:n(a,{href:"#",last:!0,onClick:i=>i.preventDefault(),children:n(h,{size:15})})})]}),v=()=>t(o,{className:"d-flex mt-3",listClassName:"pagination-warning",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),first:!0,children:n(c,{size:15})})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),last:!0,children:n(h,{size:15})})})]}),C=()=>t(P,{children:[t(r,{xl:"4",lg:"12",children:[n("h5",{className:"text-start",children:"Left Aligned"}),t(o,{className:"d-flex justify-content-start mt-2",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})]}),t(r,{xl:"4",lg:"12",children:[n("h5",{className:"text-center",children:"Center Aligned"}),t(o,{className:"d-flex justify-content-center mt-2",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})]}),t(r,{xl:"4",lg:"12",children:[n("h5",{className:"text-end",children:"Right Aligned"}),t(o,{className:"d-flex justify-content-end mt-2",children:[n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})})]})]})]}),D=()=>t(o,{className:"d-flex mt-3",children:[n(e,{className:"prev-item",children:n(a,{href:"#",onClick:i=>i.preventDefault()})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"6"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"7"})}),n(e,{className:"next-item",children:n(a,{href:"#",onClick:i=>i.preventDefault()})})]}),x=()=>t(o,{className:"d-flex mt-3",children:[n(e,{children:t(a,{className:"text-nowrap",href:"#",first:!0,children:[n(c,{className:"align-middle",size:15}),n("span",{className:"align-middle",children:"Prev"})]})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"1"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"2"})}),n(e,{active:!0,children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"3"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"4"})}),n(e,{children:n(a,{href:"#",onClick:i=>i.preventDefault(),children:"5"})}),n(e,{children:t(a,{className:"text-nowrap",href:"#",last:!0,children:[n("span",{className:"align-middle",children:"Next"}),n(h,{className:"align-middle",size:15})]})})]}),N=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'

const PaginationBasic = () => {
  return (
    <Pagination className='d-flex mt-3'>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationBasic
  `})}),z=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationSeparated = () => {
  return (
    <Pagination className='d-flex mt-3'>
      <PaginationItem className='prev-item'>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
      <PaginationItem className='next-item'>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationSeparated
  `})}),R=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationIconsAndText = () => {
  return (
    <Pagination className='d-flex mt-3'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} /> Prev
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          Next
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationIconsAndText
  `})}),w=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationIcons = () => {
  return (
    <Pagination className='d-flex mt-3'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationIcons
  `})}),j=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationSuccess = () => {
  return (
    <Pagination className='d-flex mt-3' listClassName='pagination-success'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationSuccess

  `})}),S=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationDanger = () => {
  return (
    <Pagination className='d-flex mt-3' listClassName='pagination-danger'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationDanger

  `})}),A=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationInfo = () => {
  return (
    <Pagination className='d-flex mt-3' listClassName='pagination-info'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationInfo

  `})}),y=n("pre",{children:n("code",{className:"language-jsx",children:`

import { Pagination, PaginationItem, PaginationLink } from 'reactstrap'
import { ChevronLeft, ChevronRight } from 'react-feather'

const PaginationWarning = () => {
  return (
    <Pagination className='d-flex mt-3' listClassName='pagination-warning'>
      <PaginationItem>
        <PaginationLink href='#' first>
          <ChevronLeft size={15} />
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>1</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>2</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>3</PaginationLink>
      </PaginationItem>
      <PaginationItem active>
        <PaginationLink href='#'>4</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>5</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>6</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#'>7</PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href='#' last>
          <ChevronRight size={15} />
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  )
}
export default PaginationWarning
  `})}),B=n("pre",{children:n("code",{className:"language-jsx",children:`

import {
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Col
} from 'reactstrap'

const PaginationPositions = () => {
  return (
    <Row>
      <Col xl='4' lg='12'>
        <h5 className='text-start'>Left Aligned</h5>
        <Pagination className='d-flex justify-content-start mt-3'>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
      <Col xl='4' lg='12'>
        <h5 className='text-center'>Center Aligned</h5>
        <Pagination className='d-flex justify-content-center mt-3'>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
      <Col xl='4' lg='12'>
        <h5 className='text-end'>Right Aligned</h5>
        <Pagination className='d-flex justify-content-end mt-3'>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
    </Row>
  )
}
export default PaginationPositions
  `})}),T=n("pre",{children:n("code",{className:"language-jsx",children:`

import {
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Col
} from 'reactstrap'

const PaginationPositions = () => {
  return (
    <Row className='align-items-center'>
      <Col xl='4' lg='12'>
        <Pagination size='lg'>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
      <Col xl='4' lg='12'>
        <Pagination>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
      <Col xl='4' lg='12'>
        <Pagination size='sm'>
          <PaginationItem>
            <PaginationLink href='#'>1</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>2</PaginationLink>
          </PaginationItem>
          <PaginationItem active>
            <PaginationLink href='#'>3</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>4</PaginationLink>
          </PaginationItem>
          <PaginationItem>
            <PaginationLink href='#'>5</PaginationLink>
          </PaginationItem>
        </Pagination>
      </Col>
    </Row>
  )
}
export default PaginationPositions
  `})}),X=()=>(f.exports.useEffect(()=>{d.highlightAll()},[]),t(f.exports.Fragment,{children:[n(m,{title:"Pagination",data:[{title:"Components"},{title:"Pagination"}]}),t(P,{className:"match-height",children:[n(r,{md:"6",sm:"12",children:t(g,{title:"Basic Pagination",code:N,children:[n(l,{children:"A basic pagination with active item."}),n(L,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Separated Pagination",code:z,children:[t(l,{children:["To create separated pagination use ",n("code",{children:".prev-item"})," class for the first item and"," ",n("code",{children:".next-item"})," for the last item."]}),n(D,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"With Icon & Text",code:R,children:[n(l,{children:"Pagination with icon and text."}),n(x,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Icons Only",code:w,children:[n(l,{children:"Pagination with only icons."}),n(k,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Success",code:j,children:[t(l,{children:["Use class ",n("code",{children:".pagination-success"})," with ",n("code",{children:"pagination"})," tag."]}),n(u,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Danger",code:S,children:[t(l,{children:["Use class ",n("code",{children:".pagination-danger"})," with ",n("code",{children:"pagination"})," tag."]}),n(p,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Info",code:A,children:[t(l,{children:["Use class ",n("code",{children:".pagination-info"})," with ",n("code",{children:"pagination"})," tag."]}),n(s,{})]})}),n(r,{md:"6",sm:"12",children:t(g,{title:"Warning",code:y,children:[t(l,{children:["Use class ",n("code",{children:".pagination-warning"})," with ",n("code",{children:"pagination"})," tag."]}),n(v,{})]})})]}),t(P,{children:[n(r,{sm:"12",children:t(g,{title:"Positions",code:B,children:[t(l,{children:["Use classes ",n("code",{children:".justify-content-[direction]"})," with ",n("code",{children:"pagination"})," tag."]}),n(C,{})]})}),n(r,{sm:"12",children:t(g,{title:"Sizes",code:T,children:[t(l,{children:["Use prop ",n("code",{children:'size="lg"'})," for large size pagination & use ",n("code",{children:'size="sm"'}),"for small size pagination."]}),n(I,{})]})})]})]}));export{X as default};
