import{r as l,I as a,k as e,bP as k}from"./index.3cf7fe2c.js";import{R as b,C as p}from"./Col.6ede14e5.js";import{C as d}from"./index.c1668105.js";import{B as g}from"./index.7b231c77.js";import{N as u}from"./Nav.2b19a122.js";import{R as t,V as r,J as f,N as v,b as y,j as w}from"./App.078e8de4.js";import{T as m,a as i}from"./TabPane.3a6d0a47.js";import"./Card.84516876.js";import"./CardBody.34141036.js";import"./CardHeader.acdabf3c.js";import"./CardTitle.51f38a88.js";import"./code.ac4caa14.js";import"./UncontrolledButtonDropdown.3408d595.js";const j=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{className:"justify-content-end",tabs:!0,children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Home"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Service"})}),e(t,{children:e(r,{disabled:!0,children:"Disabled"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Account"})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert macaroon dessert drag\xE9e."}),e("p",{children:"Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert macaroon dessert drag\xE9e."})]}),a(i,{tabId:"2",children:[e("p",{children:"Lemon drops caramels macaroon muffin. Icing chupa chups cupcake chupa chups cheesecake chocolate cake jelly marzipan. Candy icing apple pie powder drag\xE9e bear claw sweet roll. Drag\xE9e liquorice ice cream jujubes. Lemon drops lollipop donut cupcake macaroon icing. Wafer lemon drops jelly. Bear claw candy wafer wafer jelly cake biscuit."}),e("p",{children:"Liquorice tootsie roll cheesecake muffin chupa chups toffee toffee. Pie sesame snaps biscuit sweet roll. Tiramisu cake oat cake croissant halvah candy brownie croissant. Bonbon sugar plum muffin tart brownie macaroon lollipop drag\xE9e. Jujubes halvah cheesecake."})]}),a(i,{tabId:"3",children:[e("p",{children:"Danish tiramisu donut chocolate bar. Toffee oat cake candy toffee pudding souffl\xE9 lemon drops. Gummi bears cake oat cake. Tiramisu sugar plum sugar plum cake marzipan cake. Wafer muffin marshmallow biscuit oat cake sweet roll danish. Chocolate jelly topping dessert donut. Cheesecake jelly-o carrot cake carrot cake candy canes jelly."}),e("p",{children:"Wafer chocolate caramels jujubes biscuit powder marzipan. Lollipop gingerbread muffin. Tiramisu brownie tart marshmallow wafer sweet caramels croissant chocolate bar. Sweet marzipan toffee muffin sugar plum marzipan. Souffl\xE9 bear claw muffin cake powder danish drag\xE9e."})]})]})]})},C=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{tabs:!0,children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Home"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Service"})}),e(t,{children:e(r,{disabled:!0,children:"Disabled"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Account"})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Candy canes donut chupa chups candy canes lemon drops oat cake wafer. Cotton candy candy canes marzipan carrot cake. Sesame snaps lemon drops candy marzipan donut brownie tootsie roll. Icing croissant bonbon biscuit gummi bears. Pudding candy canes sugar plum cookie chocolate cake powder croissant."}),e("p",{children:"Carrot cake tiramisu danish candy cake muffin croissant tart dessert. Tiramisu caramels candy canes chocolate cake sweet roll liquorice icing cupcake. Candy cookie sweet roll bear claw sweet roll."})]}),a(i,{tabId:"2",children:[e("p",{children:"Drag\xE9e jujubes caramels tootsie roll gummies gummies icing bonbon. Candy jujubes cake cotton candy. Jelly-o lollipop oat cake marshmallow fruitcake candy canes toffee. Jelly oat cake pudding jelly beans brownie lemon drops ice cream halvah muffin. Brownie candy tiramisu macaroon tootsie roll danish."}),e("p",{children:"Croissant pie cheesecake sweet roll. Gummi bears cotton candy tart jelly-o caramels apple pie jelly danish marshmallow. Icing caramels lollipop topping. Bear claw powder sesame snaps."})]}),a(i,{tabId:"3",children:[e("p",{children:"Gingerbread cake cheesecake lollipop topping bonbon chocolate sesame snaps. Dessert macaroon bonbon carrot cake biscuit. Lollipop lemon drops cake gingerbread liquorice. Sweet gummies drag\xE9e. Donut bear claw pie halvah oat cake cotton candy sweet roll. Cotton candy sweet roll donut ice cream."}),e("p",{children:"Halvah bonbon topping halvah ice cream cake candy. Wafer gummi bears chocolate cake topping powder. Sweet marzipan cheesecake jelly-o powder wafer lemon drops lollipop cotton candy."})]})]})]})},N=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{tabs:!0,children:[e(t,{children:a(r,{active:c==="1",onClick:()=>{o("1")},children:[e(f,{size:14}),e("span",{className:"align-middle",children:"Home"})]})}),e(t,{children:a(r,{active:c==="2",onClick:()=>{o("2")},children:[e(v,{size:14}),e("span",{className:"align-middle",children:"Service"})]})}),e(t,{children:a(r,{disabled:!0,children:[e(y,{size:14}),e("span",{className:"align-middle",children:"Disabled"})]})}),e(t,{children:a(r,{active:c==="3",onClick:()=>{o("3")},children:[e(w,{size:14}),e("span",{className:"align-middle",children:"Account"})]})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Candy canes donut chupa chups candy canes lemon drops oat cake wafer. Cotton candy candy canes marzipan carrot cake. Sesame snaps lemon drops candy marzipan donut brownie tootsie roll. Icing croissant bonbon biscuit gummi bears. Pudding candy canes sugar plum cookie chocolate cake powder croissant."}),e("p",{children:"Carrot cake tiramisu danish candy cake muffin croissant tart dessert. Tiramisu caramels candy canes chocolate cake sweet roll liquorice icing cupcake. Candy cookie sweet roll bear claw sweet roll."})]}),a(i,{tabId:"2",children:[e("p",{children:"Drag\xE9e jujubes caramels tootsie roll gummies gummies icing bonbon. Candy jujubes cake cotton candy. Jelly-o lollipop oat cake marshmallow fruitcake candy canes toffee. Jelly oat cake pudding jelly beans brownie lemon drops ice cream halvah muffin. Brownie candy tiramisu macaroon tootsie roll danish."}),e("p",{children:"Croissant pie cheesecake sweet roll. Gummi bears cotton candy tart jelly-o caramels apple pie jelly danish marshmallow. Icing caramels lollipop topping. Bear claw powder sesame snaps."})]}),a(i,{tabId:"3",children:[e("p",{children:"Gingerbread cake cheesecake lollipop topping bonbon chocolate sesame snaps. Dessert macaroon bonbon carrot cake biscuit. Lollipop lemon drops cake gingerbread liquorice. Sweet gummies drag\xE9e. Donut bear claw pie halvah oat cake cotton candy sweet roll. Cotton candy sweet roll donut ice cream."}),e("p",{children:"Halvah bonbon topping halvah ice cream cake candy. Wafer gummi bears chocolate cake topping powder. Sweet marzipan cheesecake jelly-o powder wafer lemon drops lollipop cotton candy."})]})]})]})},T=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{tabs:!0,fill:!0,children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Home"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Profile"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Messages"})}),e(t,{children:e(r,{active:c==="4",onClick:()=>{o("4")},children:"Settings"})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Chocolate cake sweet roll lemon drops marzipan chocolate cake cupcake cotton candy. Drag\xE9e ice cream drag\xE9e biscuit chupa chups bear claw cupcake brownie cotton candy. Sesame snaps topping cupcake cake. Macaroon lemon drops gummies danish marzipan donut."}),e("p",{children:"Chocolate bar souffl\xE9 tiramisu tiramisu jelly-o carrot cake gummi bears cake. Candy canes wafer croissant donut bonbon drag\xE9e bear claw jelly sugar plum. Sweet lemon drops caramels croissant cheesecake jujubes carrot cake fruitcake. Halvah biscuit lemon drops fruitcake tart."})]}),a(i,{tabId:"2",children:[e("p",{children:"Bear claw jelly beans wafer pastry jelly beans candy macaroon biscuit topping. Sesame snaps lemon drops donut gingerbread dessert cotton candy wafer croissant jelly beans. Sweet roll halvah gingerbread bonbon apple pie gummies chocolate bar pastry gummi bears."}),e("p",{children:"Croissant danish chocolate bar pie muffin. Gummi bears marshmallow chocolate bar bear claw. Fruitcake halvah chupa chups drag\xE9e carrot cake cookie. Carrot cake oat cake cake chocolate bar cheesecake. Wafer gingerbread sweet roll candy chocolate bar gingerbread."})]}),a(i,{tabId:"3",children:[e("p",{children:"Croissant jelly tootsie roll candy canes. Donut sugar plum jujubes sweet roll chocolate cake wafer. Tart caramels jujubes. Drag\xE9e tart oat cake. Fruitcake cheesecake danish. Danish topping candy jujubes. Candy canes candy canes lemon drops caramels tiramisu chocolate bar pie."}),e("p",{children:"Gummi bears tootsie roll cake wafer. Gummies powder apple pie bear claw. Caramels bear claw fruitcake topping lemon drops. Carrot cake macaroon ice cream liquorice donut souffl\xE9. Gummi bears carrot cake toffee bonbon gingerbread lemon drops chocolate cake."})]}),a(i,{tabId:"4",children:[e("p",{children:"Candy canes halvah biscuit muffin dessert biscuit marzipan. Gummi bears marzipan bonbon chupa chups biscuit lollipop topping. Muffin sweet apple pie sweet roll jujubes chocolate. Topping cake chupa chups chocolate bar tiramisu tart sweet roll chocolate cake."}),e("p",{children:"Jelly beans caramels muffin wafer sesame snaps chupa chups chocolate cake pastry halvah. Sugar plum cotton candy macaroon tootsie roll topping. Liquorice topping chocolate cake tart tootsie roll danish bear claw. Donut candy canes marshmallow. Wafer cookie apple pie."})]})]})]})},x=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{className:"justify-content-center",tabs:!0,children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Home"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Service"})}),e(t,{children:e(r,{disabled:!0,children:"Disabled"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Account"})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert macaroon dessert drag\xE9e."}),e("p",{children:"Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert macaroon dessert drag\xE9e."})]}),a(i,{tabId:"2",children:[e("p",{children:"Lemon drops caramels macaroon muffin. Icing chupa chups cupcake chupa chups cheesecake chocolate cake jelly marzipan. Candy icing apple pie powder drag\xE9e bear claw sweet roll. Drag\xE9e liquorice ice cream jujubes. Lemon drops lollipop donut cupcake macaroon icing. Wafer lemon drops jelly. Bear claw candy wafer wafer jelly cake biscuit."}),e("p",{children:"Liquorice tootsie roll cheesecake muffin chupa chups toffee toffee. Pie sesame snaps biscuit sweet roll. Tiramisu cake oat cake croissant halvah candy brownie croissant. Bonbon sugar plum muffin tart brownie macaroon lollipop drag\xE9e. Jujubes halvah cheesecake."})]}),a(i,{tabId:"3",children:[e("p",{children:"Danish tiramisu donut chocolate bar. Toffee oat cake candy toffee pudding souffl\xE9 lemon drops. Gummi bears cake oat cake. Tiramisu sugar plum sugar plum cake marzipan cake. Wafer muffin marshmallow biscuit oat cake sweet roll danish. Chocolate jelly topping dessert donut. Cheesecake jelly-o carrot cake carrot cake candy canes jelly."}),e("p",{children:"Wafer chocolate caramels jujubes biscuit powder marzipan. Lollipop gingerbread muffin. Tiramisu brownie tart marshmallow wafer sweet caramels croissant chocolate bar. Sweet marzipan toffee muffin sugar plum marzipan. Souffl\xE9 bear claw muffin cake powder danish drag\xE9e."})]})]})]})},I=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a(l.exports.Fragment,{children:[a(u,{tabs:!0,justified:!0,children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Home"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Profile"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Messages"})}),e(t,{children:e(r,{active:c==="4",onClick:()=>{o("4")},children:"Settings"})})]}),a(m,{className:"py-50",activeTab:c,children:[a(i,{tabId:"1",children:[e("p",{children:"Chocolate cake sweet roll lemon drops marzipan chocolate cake cupcake cotton candy. Drag\xE9e ice cream drag\xE9e biscuit chupa chups bear claw cupcake brownie cotton candy. Sesame snaps topping cupcake cake. Macaroon lemon drops gummies danish marzipan donut."}),e("p",{children:"Chocolate bar souffl\xE9 tiramisu tiramisu jelly-o carrot cake gummi bears cake. Candy canes wafer croissant donut bonbon drag\xE9e bear claw jelly sugar plum. Sweet lemon drops caramels croissant cheesecake jujubes carrot cake fruitcake. Halvah biscuit lemon drops fruitcake tart."})]}),a(i,{tabId:"2",children:[e("p",{children:"Bear claw jelly beans wafer pastry jelly beans candy macaroon biscuit topping. Sesame snaps lemon drops donut gingerbread dessert cotton candy wafer croissant jelly beans. Sweet roll halvah gingerbread bonbon apple pie gummies chocolate bar pastry gummi bears."}),e("p",{children:"Croissant danish chocolate bar pie muffin. Gummi bears marshmallow chocolate bar bear claw. Fruitcake halvah chupa chups drag\xE9e carrot cake cookie. Carrot cake oat cake cake chocolate bar cheesecake. Wafer gingerbread sweet roll candy chocolate bar gingerbread."})]}),a(i,{tabId:"3",children:[e("p",{children:"Croissant jelly tootsie roll candy canes. Donut sugar plum jujubes sweet roll chocolate cake wafer. Tart caramels jujubes. Drag\xE9e tart oat cake. Fruitcake cheesecake danish. Danish topping candy jujubes. Candy canes candy canes lemon drops caramels tiramisu chocolate bar pie."}),e("p",{children:"Gummi bears tootsie roll cake wafer. Gummies powder apple pie bear claw. Caramels bear claw fruitcake topping lemon drops. Carrot cake macaroon ice cream liquorice donut souffl\xE9. Gummi bears carrot cake toffee bonbon gingerbread lemon drops chocolate cake."})]}),a(i,{tabId:"4",children:[e("p",{children:"Candy canes halvah biscuit muffin dessert biscuit marzipan. Gummi bears marzipan bonbon chupa chups biscuit lollipop topping. Muffin sweet apple pie sweet roll jujubes chocolate. Topping cake chupa chups chocolate bar tiramisu tart sweet roll chocolate cake."}),e("p",{children:"Jelly beans caramels muffin wafer sesame snaps chupa chups chocolate cake pastry halvah. Sugar plum cotton candy macaroon tootsie roll topping. Liquorice topping chocolate cake tart tootsie roll danish bear claw. Donut candy canes marshmallow. Wafer cookie apple pie."})]})]})]})},E=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a("div",{className:"nav-vertical",children:[a(u,{tabs:!0,className:"nav-left",children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Tab 1"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Tab 2"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Tab 3"})})]}),a(m,{activeTab:c,children:[e(i,{tabId:"1",children:e("p",{children:"Oat cake marzipan cake lollipop caramels wafer pie jelly beans. Icing halvah chocolate cake carrot cake. Jelly beans carrot cake marshmallow gingerbread chocolate cake. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Gummies cupcake croissant."})}),e(i,{tabId:"2",children:e("p",{children:"Sugar plum tootsie roll biscuit caramels. Liquorice brownie pastry cotton candy oat cake fruitcake jelly chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Pudding caramels pastry powder cake souffl\xE9 wafer caramels. Jelly-o pie cupcake."})}),e(i,{tabId:"3",children:e("p",{children:"Icing croissant powder jelly bonbon cake marzipan fruitcake. Tootsie roll marzipan tart marshmallow pastry cupcake chupa chups cookie. Fruitcake dessert lollipop pudding jelly. Cookie drag\xE9e jujubes croissant lemon drops cotton candy. Carrot cake candy canes powder donut toffee cookie."})})]})]})},L=()=>{const[c,s]=l.exports.useState("1"),o=n=>{c!==n&&s(n)};return a("div",{className:"nav-vertical",children:[a(u,{tabs:!0,className:"nav-right",children:[e(t,{children:e(r,{active:c==="1",onClick:()=>{o("1")},children:"Tab 1"})}),e(t,{children:e(r,{active:c==="2",onClick:()=>{o("2")},children:"Tab 2"})}),e(t,{children:e(r,{active:c==="3",onClick:()=>{o("3")},children:"Tab 3"})})]}),a(m,{activeTab:c,children:[e(i,{tabId:"1",children:e("p",{children:"Oat cake marzipan cake lollipop caramels wafer pie jelly beans. Icing halvah chocolate cake carrot cake. Jelly beans carrot cake marshmallow gingerbread chocolate cake. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Gummies cupcake croissant."})}),e(i,{tabId:"2",children:e("p",{children:"Sugar plum tootsie roll biscuit caramels. Liquorice brownie pastry cotton candy oat cake fruitcake jelly chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Pudding caramels pastry powder cake souffl\xE9 wafer caramels. Jelly-o pie cupcake."})}),e(i,{tabId:"3",children:e("p",{children:"Icing croissant powder jelly bonbon cake marzipan fruitcake. Tootsie roll marzipan tart marshmallow pastry cupcake chupa chups cookie. Fruitcake dessert lollipop pudding jelly. Cookie drag\xE9e jujubes croissant lemon drops cotton candy. Carrot cake candy canes powder donut toffee cookie."})})]})]})},h=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsBasic = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  return (
    <React.Fragment>
      <Nav tabs>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Service
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink disabled>Disabled</NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Account
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent className='py-50' activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Candy canes donut chupa chups candy canes lemon drops oat cake wafer. Cotton candy candy canes marzipan
            carrot cake. Sesame snaps lemon drops candy marzipan donut brownie tootsie roll. Icing croissant bonbon
            biscuit gummi bears. Pudding candy canes sugar plum cookie chocolate cake powder croissant.
          </p>
          <p>
            Carrot cake tiramisu danish candy cake muffin croissant tart dessert. Tiramisu caramels candy canes
            chocolate cake sweet roll liquorice icing cupcake. Candy cookie sweet roll bear claw sweet roll.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Drag\xE9e jujubes caramels tootsie roll gummies gummies icing bonbon. Candy jujubes cake cotton candy. Jelly-o
            lollipop oat cake marshmallow fruitcake candy canes toffee. Jelly oat cake pudding jelly beans brownie lemon
            drops ice cream halvah muffin. Brownie candy tiramisu macaroon tootsie roll danish.
          </p>
          <p>
            Croissant pie cheesecake sweet roll. Gummi bears cotton candy tart jelly-o caramels apple pie jelly danish
            marshmallow. Icing caramels lollipop topping. Bear claw powder sesame snaps.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Gingerbread cake cheesecake lollipop topping bonbon chocolate sesame snaps. Dessert macaroon bonbon carrot
            cake biscuit. Lollipop lemon drops cake gingerbread liquorice. Sweet gummies drag\xE9e. Donut bear claw pie
            halvah oat cake cotton candy sweet roll. Cotton candy sweet roll donut ice cream.
          </p>
          <p>
            Halvah bonbon topping halvah ice cream cake candy. Wafer gummi bears chocolate cake topping powder. Sweet
            marzipan cheesecake jelly-o powder wafer lemon drops lollipop cotton candy.
          </p>
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}
export default TabsBasic
`})}),S=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsVerticalLeft = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }

  return (
    <div className='nav-vertical'>
      <Nav tabs className='nav-left'>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Tab 1
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Tab 2
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Tab 3
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Oat cake marzipan cake lollipop caramels wafer pie jelly beans. Icing halvah chocolate cake carrot cake.
            Jelly beans carrot cake marshmallow gingerbread chocolate cake. Sweet fruitcake cheesecake biscuit cotton
            candy. Cookie powder marshmallow donut. Gummies cupcake croissant.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Sugar plum tootsie roll biscuit caramels. Liquorice brownie pastry cotton candy oat cake fruitcake jelly
            chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Pudding
            caramels pastry powder cake souffl\xE9 wafer caramels. Jelly-o pie cupcake.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Icing croissant powder jelly bonbon cake marzipan fruitcake. Tootsie roll marzipan tart marshmallow pastry
            cupcake chupa chups cookie. Fruitcake dessert lollipop pudding jelly. Cookie drag\xE9e jujubes croissant lemon
            drops cotton candy. Carrot cake candy canes powder donut toffee cookie.
          </p>
        </TabPane>
      </TabContent>
    </div>
  )
}
export default TabsVerticalLeft
`})}),P=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsVerticalRight = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }

  return (
    <div className='nav-vertical'>
      <Nav tabs className='nav-right'>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Tab 1
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Tab 2
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Tab 3
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Oat cake marzipan cake lollipop caramels wafer pie jelly beans. Icing halvah chocolate cake carrot cake.
            Jelly beans carrot cake marshmallow gingerbread chocolate cake. Sweet fruitcake cheesecake biscuit cotton
            candy. Cookie powder marshmallow donut. Gummies cupcake croissant.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Sugar plum tootsie roll biscuit caramels. Liquorice brownie pastry cotton candy oat cake fruitcake jelly
            chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Pudding
            caramels pastry powder cake souffl\xE9 wafer caramels. Jelly-o pie cupcake.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Icing croissant powder jelly bonbon cake marzipan fruitcake. Tootsie roll marzipan tart marshmallow pastry
            cupcake chupa chups cookie. Fruitcake dessert lollipop pudding jelly. Cookie drag\xE9e jujubes croissant lemon
            drops cotton candy. Carrot cake candy canes powder donut toffee cookie.
          </p>
        </TabPane>
      </TabContent>
    </div>
  )
}
export default TabsVerticalRight
`})}),z=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsFilled = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  return (
    <React.Fragment>
      <Nav tabs fill>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Profile
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Messages
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '4'}
            onClick={() => {
              toggle('4')
            }}
          >
            Settings
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent className='py-50' activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Chocolate cake sweet roll lemon drops marzipan chocolate cake cupcake cotton candy. Drag\xE9e ice cream drag\xE9e
            biscuit chupa chups bear claw cupcake brownie cotton candy. Sesame snaps topping cupcake cake. Macaroon
            lemon drops gummies danish marzipan donut.
          </p>
          <p>
            Chocolate bar souffl\xE9 tiramisu tiramisu jelly-o carrot cake gummi bears cake. Candy canes wafer croissant
            donut bonbon drag\xE9e bear claw jelly sugar plum. Sweet lemon drops caramels croissant cheesecake jujubes
            carrot cake fruitcake. Halvah biscuit lemon drops fruitcake tart.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Bear claw jelly beans wafer pastry jelly beans candy macaroon biscuit topping. Sesame snaps lemon drops
            donut gingerbread dessert cotton candy wafer croissant jelly beans. Sweet roll halvah gingerbread bonbon
            apple pie gummies chocolate bar pastry gummi bears.
          </p>
          <p>
            Croissant danish chocolate bar pie muffin. Gummi bears marshmallow chocolate bar bear claw. Fruitcake halvah
            chupa chups drag\xE9e carrot cake cookie. Carrot cake oat cake cake chocolate bar cheesecake. Wafer gingerbread
            sweet roll candy chocolate bar gingerbread.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Croissant jelly tootsie roll candy canes. Donut sugar plum jujubes sweet roll chocolate cake wafer. Tart
            caramels jujubes. Drag\xE9e tart oat cake. Fruitcake cheesecake danish. Danish topping candy jujubes. Candy
            canes candy canes lemon drops caramels tiramisu chocolate bar pie.
          </p>
          <p>
            Gummi bears tootsie roll cake wafer. Gummies powder apple pie bear claw. Caramels bear claw fruitcake
            topping lemon drops. Carrot cake macaroon ice cream liquorice donut souffl\xE9. Gummi bears carrot cake toffee
            bonbon gingerbread lemon drops chocolate cake.
          </p>
        </TabPane>
        <TabPane tabId='4'>
          <p>
            Candy canes halvah biscuit muffin dessert biscuit marzipan. Gummi bears marzipan bonbon chupa chups biscuit
            lollipop topping. Muffin sweet apple pie sweet roll jujubes chocolate. Topping cake chupa chups chocolate
            bar tiramisu tart sweet roll chocolate cake.
          </p>
          <p>
            Jelly beans caramels muffin wafer sesame snaps chupa chups chocolate cake pastry halvah. Sugar plum cotton
            candy macaroon tootsie roll topping. Liquorice topping chocolate cake tart tootsie roll danish bear claw.
            Donut candy canes marshmallow. Wafer cookie apple pie.
          </p>
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}
export default TabsFilled
`})}),B=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsJustified = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  return (
    <React.Fragment>
      <Nav tabs justified>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Profile
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Messages
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '4'}
            onClick={() => {
              toggle('4')
            }}
          >
            Settings
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent className='py-50' activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Chocolate cake sweet roll lemon drops marzipan chocolate cake cupcake cotton candy. Drag\xE9e ice cream drag\xE9e
            biscuit chupa chups bear claw cupcake brownie cotton candy. Sesame snaps topping cupcake cake. Macaroon
            lemon drops gummies danish marzipan donut.
          </p>
          <p>
            Chocolate bar souffl\xE9 tiramisu tiramisu jelly-o carrot cake gummi bears cake. Candy canes wafer croissant
            donut bonbon drag\xE9e bear claw jelly sugar plum. Sweet lemon drops caramels croissant cheesecake jujubes
            carrot cake fruitcake. Halvah biscuit lemon drops fruitcake tart.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Bear claw jelly beans wafer pastry jelly beans candy macaroon biscuit topping. Sesame snaps lemon drops
            donut gingerbread dessert cotton candy wafer croissant jelly beans. Sweet roll halvah gingerbread bonbon
            apple pie gummies chocolate bar pastry gummi bears.
          </p>
          <p>
            Croissant danish chocolate bar pie muffin. Gummi bears marshmallow chocolate bar bear claw. Fruitcake halvah
            chupa chups drag\xE9e carrot cake cookie. Carrot cake oat cake cake chocolate bar cheesecake. Wafer gingerbread
            sweet roll candy chocolate bar gingerbread.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Croissant jelly tootsie roll candy canes. Donut sugar plum jujubes sweet roll chocolate cake wafer. Tart
            caramels jujubes. Drag\xE9e tart oat cake. Fruitcake cheesecake danish. Danish topping candy jujubes. Candy
            canes candy canes lemon drops caramels tiramisu chocolate bar pie.
          </p>
          <p>
            Gummi bears tootsie roll cake wafer. Gummies powder apple pie bear claw. Caramels bear claw fruitcake
            topping lemon drops. Carrot cake macaroon ice cream liquorice donut souffl\xE9. Gummi bears carrot cake toffee
            bonbon gingerbread lemon drops chocolate cake.
          </p>
        </TabPane>
        <TabPane tabId='4'>
          <p>
            Candy canes halvah biscuit muffin dessert biscuit marzipan. Gummi bears marzipan bonbon chupa chups biscuit
            lollipop topping. Muffin sweet apple pie sweet roll jujubes chocolate. Topping cake chupa chups chocolate
            bar tiramisu tart sweet roll chocolate cake.
          </p>
          <p>
            Jelly beans caramels muffin wafer sesame snaps chupa chups chocolate cake pastry halvah. Sugar plum cotton
            candy macaroon tootsie roll topping. Liquorice topping chocolate cake tart tootsie roll danish bear claw.
            Donut candy canes marshmallow. Wafer cookie apple pie.
          </p>
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}
export default TabsJustified
`})}),D=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsCentered = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  return (
    <React.Fragment>
      <Nav className='justify-content-center' tabs>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Service
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink disabled>Disabled</NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Account
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent className='py-50' activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon
            jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o
            tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert
            macaroon dessert drag\xE9e.
          </p>
          <p>
            Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon
            jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o
            tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert
            macaroon dessert drag\xE9e.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Lemon drops caramels macaroon muffin. Icing chupa chups cupcake chupa chups cheesecake chocolate cake jelly
            marzipan. Candy icing apple pie powder drag\xE9e bear claw sweet roll. Drag\xE9e liquorice ice cream jujubes.
            Lemon drops lollipop donut cupcake macaroon icing. Wafer lemon drops jelly. Bear claw candy wafer wafer
            jelly cake biscuit.
          </p>
          <p>
            Liquorice tootsie roll cheesecake muffin chupa chups toffee toffee. Pie sesame snaps biscuit sweet roll.
            Tiramisu cake oat cake croissant halvah candy brownie croissant. Bonbon sugar plum muffin tart brownie
            macaroon lollipop drag\xE9e. Jujubes halvah cheesecake.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Danish tiramisu donut chocolate bar. Toffee oat cake candy toffee pudding souffl\xE9 lemon drops. Gummi bears
            cake oat cake. Tiramisu sugar plum sugar plum cake marzipan cake. Wafer muffin marshmallow biscuit oat cake
            sweet roll danish. Chocolate jelly topping dessert donut. Cheesecake jelly-o carrot cake carrot cake candy
            canes jelly.
          </p>
          <p>
            Wafer chocolate caramels jujubes biscuit powder marzipan. Lollipop gingerbread muffin. Tiramisu brownie tart
            marshmallow wafer sweet caramels croissant chocolate bar. Sweet marzipan toffee muffin sugar plum marzipan.
            Souffl\xE9 bear claw muffin cake powder danish drag\xE9e.
          </p>
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}
export default TabsCentered
`})}),q=e("pre",{children:e("code",{className:"language-jsx",children:`
import React, { useState } from 'react'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap'

const TabsEnd = () => {
  const [active, setActive] = useState('1')

  const toggle = tab => {
    if (active !== tab) {
      setActive(tab)
    }
  }
  return (
    <React.Fragment>
      <Nav className='justify-content-end' tabs>
        <NavItem>
          <NavLink
            active={active === '1'}
            onClick={() => {
              toggle('1')
            }}
          >
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '2'}
            onClick={() => {
              toggle('2')
            }}
          >
            Service
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink disabled>Disabled</NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            active={active === '3'}
            onClick={() => {
              toggle('3')
            }}
          >
            Account
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent className='py-50' activeTab={active}>
        <TabPane tabId='1'>
          <p>
            Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon
            jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o
            tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert
            macaroon dessert drag\xE9e.
          </p>
          <p>
            Pie fruitcake lollipop. Chupa chups apple pie marzipan danish souffl\xE9 souffl\xE9 oat cake gingerbread. Bonbon
            jujubes donut gummies sesame snaps cookie gingerbread cotton candy pastry. Biscuit sugar plum jelly-o
            tootsie roll gummies cookie croissant cotton candy. Bear claw lollipop liquorice chocolate topping dessert
            macaroon dessert drag\xE9e.
          </p>
        </TabPane>
        <TabPane tabId='2'>
          <p>
            Lemon drops caramels macaroon muffin. Icing chupa chups cupcake chupa chups cheesecake chocolate cake jelly
            marzipan. Candy icing apple pie powder drag\xE9e bear claw sweet roll. Drag\xE9e liquorice ice cream jujubes.
            Lemon drops lollipop donut cupcake macaroon icing. Wafer lemon drops jelly. Bear claw candy wafer wafer
            jelly cake biscuit.
          </p>
          <p>
            Liquorice tootsie roll cheesecake muffin chupa chups toffee toffee. Pie sesame snaps biscuit sweet roll.
            Tiramisu cake oat cake croissant halvah candy brownie croissant. Bonbon sugar plum muffin tart brownie
            macaroon lollipop drag\xE9e. Jujubes halvah cheesecake.
          </p>
        </TabPane>
        <TabPane tabId='3'>
          <p>
            Danish tiramisu donut chocolate bar. Toffee oat cake candy toffee pudding souffl\xE9 lemon drops. Gummi bears
            cake oat cake. Tiramisu sugar plum sugar plum cake marzipan cake. Wafer muffin marshmallow biscuit oat cake
            sweet roll danish. Chocolate jelly topping dessert donut. Cheesecake jelly-o carrot cake carrot cake candy
            canes jelly.
          </p>
          <p>
            Wafer chocolate caramels jujubes biscuit powder marzipan. Lollipop gingerbread muffin. Tiramisu brownie tart
            marshmallow wafer sweet caramels croissant chocolate bar. Sweet marzipan toffee muffin sugar plum marzipan.
            Souffl\xE9 bear claw muffin cake powder danish drag\xE9e.
          </p>
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}
export default TabsEnd
`})}),X=()=>(l.exports.useEffect(()=>{k.highlightAll()},[]),a(l.exports.Fragment,{children:[e(g,{title:"Tabs",data:[{title:"Components"},{title:"Tabs"}]}),a(b,{children:[e(p,{xl:"6",lg:"12",children:e(d,{title:"Basic Tabs",code:h,children:e(C,{})})}),e(p,{xl:"6",lg:"12",children:e(d,{title:"Tabs with icons",code:h,children:e(N,{})})})]}),a(b,{children:[e(p,{xl:"6",lg:"12",children:e(d,{title:"Vertical Left Tabs",code:S,children:e(E,{})})}),e(p,{xl:"6",lg:"12",children:e(d,{title:"Vertical Right Tabs",code:P,children:e(L,{})})})]}),a(b,{children:[e(p,{xl:"6",lg:"12",children:e(d,{title:"Filled",code:z,children:e(T,{})})}),e(p,{xl:"6",lg:"12",children:e(d,{title:"Justified",code:B,children:e(I,{})})}),e(p,{xl:"6",lg:"12",children:e(d,{title:"Centered",code:D,children:e(x,{})})}),e(p,{xl:"6",lg:"12",children:e(d,{title:"End",code:q,children:e(j,{})})})]})]}));export{X as default};
