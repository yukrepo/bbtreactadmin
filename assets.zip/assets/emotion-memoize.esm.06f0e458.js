function c(t){var n=Object.create(null);return function(e){return n[e]===void 0&&(n[e]=t(e)),n[e]}}export{c as m};
